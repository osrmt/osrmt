package com.osrmt.appclient.common;

public class NullArtifactException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
