/*
 * Created on 2-Apr-2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package database;

/**
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Null {
	public Object type = null;
	public Null(Object o) {
		this.type = o;
	}
}
