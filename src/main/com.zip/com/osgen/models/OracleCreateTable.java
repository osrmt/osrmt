package models;

public class OracleCreateTable extends CreateTableModel {

}
