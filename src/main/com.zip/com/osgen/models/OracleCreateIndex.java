package models;

public class OracleCreateIndex extends CreateIndexModel {

}
