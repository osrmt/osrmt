package com.osframework.appclient.ui.controls;

import javax.swing.Icon;
import javax.swing.JLabel;

public class UILabel extends JLabel {

	public UILabel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UILabel(Icon image, int horizontalAlignment) {
		super(image, horizontalAlignment);
		// TODO Auto-generated constructor stub
	}

	public UILabel(Icon image) {
		super(image);
		// TODO Auto-generated constructor stub
	}

	public UILabel(String text, Icon icon, int horizontalAlignment) {
		super(text, icon, horizontalAlignment);
		// TODO Auto-generated constructor stub
	}

	public UILabel(String text, int horizontalAlignment) {
		super(text, horizontalAlignment);
		// TODO Auto-generated constructor stub
	}

	public UILabel(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

}
