package com.osframework.appclient.ui.controls;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JButton;

public class UIButton extends JButton {

	public UIButton() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UIButton(Action a) {
		super(a);
		// TODO Auto-generated constructor stub
	}

	public UIButton(Icon icon) {
		super(icon);
		// TODO Auto-generated constructor stub
	}

	public UIButton(String text, Icon icon) {
		super(text, icon);
		// TODO Auto-generated constructor stub
	}

	public UIButton(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

}
