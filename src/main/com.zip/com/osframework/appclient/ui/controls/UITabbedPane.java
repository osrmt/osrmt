package com.osframework.appclient.ui.controls;

import javax.swing.JTabbedPane;

import com.jgoodies.forms.factories.Borders;

public class UITabbedPane extends JTabbedPane {

	public UITabbedPane() {
		this.setBorder(Borders.DIALOG_BORDER);
	}
}
