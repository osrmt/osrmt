/**
 * 
 */
package com.osframework.appclient.ui.tree;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * @author 
 *
 */
public class UITreeNode extends DefaultMutableTreeNode {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public UITreeNode() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param userObject
	 */
	public UITreeNode(Object userObject) {
		super(userObject);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param userObject
	 * @param allowsChildren
	 */
	public UITreeNode(Object userObject, boolean allowsChildren) {
		super(userObject, allowsChildren);
		// TODO Auto-generated constructor stub
	}

}
