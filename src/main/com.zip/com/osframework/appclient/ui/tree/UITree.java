package com.osframework.appclient.ui.tree;

import javax.swing.JTree;

public class UITree extends JTree {

}
