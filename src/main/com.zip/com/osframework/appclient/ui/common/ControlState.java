package com.osframework.appclient.ui.common;

public interface ControlState {
	
	public boolean getEnabled();
	
}
