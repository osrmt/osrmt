package com.osframework.appclient.services;

import java.io.Serializable;

public class BaseApplicationObject implements Serializable {
	
	private static final long serialVersionUID = 1L;

}
