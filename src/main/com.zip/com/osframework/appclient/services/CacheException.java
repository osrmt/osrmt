package com.osframework.appclient.services;

public class CacheException extends Exception {

	public CacheException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CacheException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CacheException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CacheException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
