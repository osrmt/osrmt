package com.osframework.ejb.reportwriter;

public class NullReportException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullReportException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NullReportException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NullReportException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NullReportException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
