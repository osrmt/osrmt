package com.osframework.datalibrary.common;

public class RetrySequenceException extends Exception {

	public RetrySequenceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RetrySequenceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RetrySequenceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RetrySequenceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}