package com.osframework.framework.logging;

public class DebugLevel {
	
	public final static int Nothing = 0;
	public final static int Error = 1;
	public final static int Warning = 2;
	public final static int Info = 3;
	public final static int Debug = 4;

}
