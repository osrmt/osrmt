package com.osframework.framework.exceptions;
import com.osframework.framework.messages.*;

public class ExceptionInfo {
	
	public static String debugFileAccess = Lang.get("Debug File Access Exception");
	public static String invalidCopyModifiedField = Lang.get("Invalid modified field to copy");

}
