package com.osframework.modellibrary.system;

import net.sf.jasperreports.engine.JasperPrint;

public class PrintDocument extends JasperPrint {

	public PrintDocument() {
		super();
		// TODO Auto-generated constructor stub
	}

}
