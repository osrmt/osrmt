//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.system;


/**
null
*/
public class RecordFileModel extends RecordFileDataModel implements Comparable {

	private static final long serialVersionUID = 1L;
	public RecordFileModel() {

	}
	
	public int compareTo(Object arg0) {
		return 0;
	}
}