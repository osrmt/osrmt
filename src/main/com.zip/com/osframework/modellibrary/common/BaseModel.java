package com.osframework.modellibrary.common;

import java.util.Comparator;

public abstract class BaseModel implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;


}
