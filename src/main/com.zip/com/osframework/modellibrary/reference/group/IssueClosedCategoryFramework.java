//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class IssueClosedCategoryFramework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public static final int NOTREPRODUCIBLE = 1392;

	private int IssueClosedCategoryRefId = 0;
	public IssueClosedCategoryFramework(int IssueClosedCategoryRefId) {
		this.IssueClosedCategoryRefId = IssueClosedCategoryRefId;		
	}

	public int getIssueClosedCategoryRefId() {
		return IssueClosedCategoryRefId;
	}

	public static IssueClosedCategoryFramework get(int IssueClosedCategoryRefId) {
		return new IssueClosedCategoryFramework(IssueClosedCategoryRefId);
	}

}
