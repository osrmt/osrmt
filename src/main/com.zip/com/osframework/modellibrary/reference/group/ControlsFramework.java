//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class ControlsFramework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;


	private int ControlsRefId = 0;
	public ControlsFramework(int ControlsRefId) {
		this.ControlsRefId = ControlsRefId;		
	}

	public int getControlsRefId() {
		return ControlsRefId;
	}

	public static ControlsFramework get(int ControlsRefId) {
		return new ControlsFramework(ControlsRefId);
	}

}
