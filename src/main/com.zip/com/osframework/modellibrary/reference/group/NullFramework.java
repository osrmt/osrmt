//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class NullFramework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public static final int NULL = 0;

	private int NullRefId = 0;
	public NullFramework(int NullRefId) {
		this.NullRefId = NullRefId;		
	}

	public int getNullRefId() {
		return NullRefId;
	}

	public static NullFramework get(int NullRefId) {
		return new NullFramework(NullRefId);
	}

}
