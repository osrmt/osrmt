//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class OriginCategoryFramework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;


	private int OriginCategoryRefId = 0;
	public OriginCategoryFramework(int OriginCategoryRefId) {
		this.OriginCategoryRefId = OriginCategoryRefId;		
	}

	public int getOriginCategoryRefId() {
		return OriginCategoryRefId;
	}

	public static OriginCategoryFramework get(int OriginCategoryRefId) {
		return new OriginCategoryFramework(OriginCategoryRefId);
	}

}
