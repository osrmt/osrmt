//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class IssueReproduceFramework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public static final int INFREQUENTLY = 1398;

	private int IssueReproduceRefId = 0;
	public IssueReproduceFramework(int IssueReproduceRefId) {
		this.IssueReproduceRefId = IssueReproduceRefId;		
	}

	public int getIssueReproduceRefId() {
		return IssueReproduceRefId;
	}

	public static IssueReproduceFramework get(int IssueReproduceRefId) {
		return new IssueReproduceFramework(IssueReproduceRefId);
	}

}
