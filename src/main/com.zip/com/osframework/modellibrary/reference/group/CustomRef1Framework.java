//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class CustomRef1Framework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;


	private int CustomRef1RefId = 0;
	public CustomRef1Framework(int CustomRef1RefId) {
		this.CustomRef1RefId = CustomRef1RefId;		
	}

	public int getCustomRef1RefId() {
		return CustomRef1RefId;
	}

	public static CustomRef1Framework get(int CustomRef1RefId) {
		return new CustomRef1Framework(CustomRef1RefId);
	}

}
