//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class IssueResolvedCategoryFramework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public static final int CODECHANGE = 1390;

	private int IssueResolvedCategoryRefId = 0;
	public IssueResolvedCategoryFramework(int IssueResolvedCategoryRefId) {
		this.IssueResolvedCategoryRefId = IssueResolvedCategoryRefId;		
	}

	public int getIssueResolvedCategoryRefId() {
		return IssueResolvedCategoryRefId;
	}

	public static IssueResolvedCategoryFramework get(int IssueResolvedCategoryRefId) {
		return new IssueResolvedCategoryFramework(IssueResolvedCategoryRefId);
	}

}
