//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class CustomRef2Framework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;


	private int CustomRef2RefId = 0;
	public CustomRef2Framework(int CustomRef2RefId) {
		this.CustomRef2RefId = CustomRef2RefId;		
	}

	public int getCustomRef2RefId() {
		return CustomRef2RefId;
	}

	public static CustomRef2Framework get(int CustomRef2RefId) {
		return new CustomRef2Framework(CustomRef2RefId);
	}

}
