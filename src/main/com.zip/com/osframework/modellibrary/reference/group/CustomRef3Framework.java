//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class CustomRef3Framework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;


	private int CustomRef3RefId = 0;
	public CustomRef3Framework(int CustomRef3RefId) {
		this.CustomRef3RefId = CustomRef3RefId;		
	}

	public int getCustomRef3RefId() {
		return CustomRef3RefId;
	}

	public static CustomRef3Framework get(int CustomRef3RefId) {
		return new CustomRef3Framework(CustomRef3RefId);
	}

}
