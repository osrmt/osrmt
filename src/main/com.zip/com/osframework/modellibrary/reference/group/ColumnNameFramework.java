//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class ColumnNameFramework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;


	private int ColumnNameRefId = 0;
	public ColumnNameFramework(int ColumnNameRefId) {
		this.ColumnNameRefId = ColumnNameRefId;		
	}

	public int getColumnNameRefId() {
		return ColumnNameRefId;
	}

	public static ColumnNameFramework get(int ColumnNameRefId) {
		return new ColumnNameFramework(ColumnNameRefId);
	}

}
