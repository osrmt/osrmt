//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class ViewFramework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;


	private int ViewRefId = 0;
	public ViewFramework(int ViewRefId) {
		this.ViewRefId = ViewRefId;		
	}

	public int getViewRefId() {
		return ViewRefId;
	}

	public static ViewFramework get(int ViewRefId) {
		return new ViewFramework(ViewRefId);
	}

}
