//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class NullGroup {

	public static final int NULL = 0;

	private int NullRefId = 0;
	public NullGroup(int NullRefId) {
		this.NullRefId = NullRefId;		
	}

	public int getNullRefId() {
		return NullRefId;
	}

}
