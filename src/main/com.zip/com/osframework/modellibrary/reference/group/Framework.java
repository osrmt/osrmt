//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.group;

public class Framework implements java.io.Serializable {

	private static final long serialVersionUID = 1L;


}
