//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.security;


/**
null
*/
public class StaffModel extends StaffDataModel {

	private static final long serialVersionUID = 1L;
	public StaffModel() {

	}
	

}