//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.security;


/**
null
*/
public class StaffSearchModel extends StaffSearchDataModel implements Comparable {

	private static final long serialVersionUID = 1L;
	public StaffSearchModel() {

	}
	
	public int compareTo(Object arg0) {
		return 0;
	}
}