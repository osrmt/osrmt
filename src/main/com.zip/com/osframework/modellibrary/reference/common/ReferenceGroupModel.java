//************ AUTO GENERATED DO NOT EDIT *********//
package com.osframework.modellibrary.reference.common;


public class ReferenceGroupModel extends ReferenceGroupDataModel implements Comparable {

	static final long serialVersionUID = 1L;
	public ReferenceGroupModel() {

	}
	
	public int compareTo(Object arg0) {
		return 0;
	}

}